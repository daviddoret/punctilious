import punctilious as pu

# Create a universe-of-discourse with basic objects for the sake of this example.
u = pu.create_universe_of_discourse(echo=True)
a1 = u.a.declare(natural_language='Dummy axiom to establish some ground propositions.')
o1 = u.o.declare()
o2 = u.o.declare()
o3 = u.o.declare()
f = u.c1.declare(arity=2, symbol='f', signal_proposition=True)
t1 = u.t.declare(echo=True)

# Elaborate a dummy theory with a set of propositions necessary for our demonstration
a = t1.include_axiom(a=a1)
t1.i.axiom_interpretation.infer_formula_statement(a=a, p=f(o1, o2), lock=False)
t1.i.axiom_interpretation.infer_formula_statement(a=a, p=f(o2, o3), lock=False)
with u.with_variable('x') as x, u.with_variable('y') as y, u.with_variable('z') as z:
    implication = t1.i.axiom_interpretation.infer_formula_statement(a=a,
        p=(f(x, y) | u.c1.land | f(y, z)) | u.c1.implies | u.c1.lnot(f(x, z)), lock=True)
t1.stabilize()

# Pose the negation hypothesis
h = t1.pose_hypothesis(hypothesis_formula=f(o1, o3), subtitle='We pose the positive hypothesis')
conjunction_introduction = h.child_theory.i.conjunction_introduction.infer_formula_statement(p=f(o1, o2), q=f(o2, o3))
variable_substitution = h.child_theory.i.variable_substitution.infer_formula_statement(p=implication,
    phi=u.c1.tupl(o1, o2, o3))
modus_ponens = h.child_theory.i.modus_ponens.infer_formula_statement(p_implies_q=variable_substitution,
    p=conjunction_introduction)

# Prove hypothesis inconsistency
h_inconsistency = t1.i.inconsistency_introduction_1.infer_formula_statement(p=h.child_statement, not_p=modus_ponens,
    t=h.child_theory, subtitle='Proof of the hypothesis inconsistency')

# And finally, use the proof-by-contradiction-1 inference-rule:
proposition_of_interest = t1.i.proof_by_refutation_1.infer_formula_statement(h=h, inc_h=h_inconsistency,
    subtitle='The proposition of interest')
