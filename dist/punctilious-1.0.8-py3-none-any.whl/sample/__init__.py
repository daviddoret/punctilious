"""This python module contains sample python scripts that illustrate *punctilious* usage."""
__version__ = "1.0.8"
