"""This python module contains mathematical theories formalized with *punctilious*."""

from theory.theory_tao_2006_the_peano_axioms import Tao2006ThePeanoAxioms
