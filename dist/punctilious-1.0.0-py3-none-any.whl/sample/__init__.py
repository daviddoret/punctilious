"""This python module contains sample python scripts that illustrate *punctilious* usage."""
