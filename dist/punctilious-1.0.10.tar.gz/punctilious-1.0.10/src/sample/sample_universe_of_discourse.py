import punctilious as pu

# Create a universe-of-discourse.
u = pu.create_universe_of_discourse(echo=True)
